
package flavour.entity;

public class PlaceOrder {
    
    public PlaceOrder(int placeOrderID, String customerName,String flavourList) {
        this.placeOrderID = placeOrderID;
        this.customerName = customerName;
        this.flavourList = flavourList;
    }

    public int placeOrderID;
    public String customerName,flavourList;

    @Override
    public String toString() {
        return String.format("%s %s %s", placeOrderID,customerName,flavourList);
    }
    
}
